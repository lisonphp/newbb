## About migrates
migrates 数据迁移

生成数据迁移
php artisan migrate --path=packages/newbee-erp-finance/database/migrations

数据回滚
php artisan migrate:rollback --path=packages/newbee-erp-finance/database/migrations
