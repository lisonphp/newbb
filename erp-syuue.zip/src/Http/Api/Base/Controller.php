<?php
namespace Newbee\Syuue\Http\Api\Base;
use Dingo\Api\Routing\Helpers;

class Controller extends \App\Http\Controllers\Controller
{
    use Helpers;
}
