## About Base
Base 控制器继承，基类

## About AbstractSearchService
AbstractSearchService 搜索服务层


## About AbstractCriteria
AbstractCriteria 搜索服务层对应的抽象层
