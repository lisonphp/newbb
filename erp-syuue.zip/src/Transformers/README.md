## About Transformers
Transformers (数据返回层) 根据不同的场景。比如A场景，B场景，返回不同的字段。
