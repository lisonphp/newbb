<?php

namespace Newbee\Finance\Repository\Contract;

use Prettus\Repository\Contracts\RepositoryInterface;

/**
 * Interface ErpReceiptCheckRepository.
 *
 * @package namespace Newbee\Track\Repository\Contract;
 */
interface ErpReceiptCheckRepository extends RepositoryInterface
{
    //
}
