<?php

namespace Newbee\Finance\Repository\Contract;

use Prettus\Repository\Contracts\RepositoryInterface;

/**
 * Interface ErpPayeeRepository.
 *
 * @package namespace Newbee\Track\Repository\Contract;
 */
interface ErpPayeeRepository extends RepositoryInterface
{
    //
}
