<?php

namespace Newbee\Finance\Repository\Contract;

use Prettus\Repository\Contracts\RepositoryInterface;

/**
 * Interface ErpReconciliationRepository.
 *
 * @package namespace Newbee\Track\Repository\Contract;
 */
interface ErpReconciliationRepository extends RepositoryInterface
{
    //
}
