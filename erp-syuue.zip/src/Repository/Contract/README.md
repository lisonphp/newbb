## About Contract
Contract 抽象层
