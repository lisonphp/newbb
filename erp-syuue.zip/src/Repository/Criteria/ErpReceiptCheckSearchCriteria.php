<?php
namespace Newbee\Finance\Repository\Criteria;
use Newbee\Finance\Http\Api\Base\AbstractCriteria;

class ErpReceiptCheckSearchCriteria extends AbstractCriteria
{

}
