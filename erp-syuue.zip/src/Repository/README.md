## About Repository
Repository 仓储层

建立 Models\ErpOrder.php 仓储层
php artisan make:repository ErpOrder

这里会生成一个接口文件，和接口的实现（抽象层）

-- 接口层(Eloquent\目录下)
-- 抽象层(Contract\目录下)

引用来源：
https://packagist.org/packages/prettus/l5-repository
