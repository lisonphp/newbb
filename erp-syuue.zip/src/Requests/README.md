## About Requests
Requests 请求层。

验证表单请求

创建表单请求验证
面对更复杂的验证情境中，你可以创建一个「表单请求」来处理更为复杂的逻辑。表单请求是包含验证逻辑的自定义请求类。可使用 Artisan 命令 :request 来创建表单请求类：

php artisan make:request StoreErpOrderRequests

————————————————
转自链接：https://learnku.com/docs/laravel/7.x/validation/7467
