<?php

namespace Newbee\Finance\Requests\ReceiptCheck;

use Illuminate\Foundation\Http\FormRequest;

class UpdateErpReceiptCheckRequest extends FormRequest
{

    /**
     * 获取应用于请求的验证规则.
     *
     * @return array
     */
    public function rules()
    {
        return [];
    }
}
